package com.example.terrariawiki.model;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

@Entity
@Table(name="Weapons")
public class WeaponsModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Поле названия не может быть пустым")
    private String name;

    @NotBlank(message = "Поле типа не может быть пустым")
    private String type;

    @NotNull(message = "Поле скорости атаки не может быть пустым")
    private double attackSpeed;


    @NotNull(message = "Поле отбрасывания не может быть пустым")
    private double knockback;
    @NotBlank(message = "Поле имени картинки не может быть пустым")
    private String imageName;
    //Связи
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable (name="Biomes_Weapons",
            joinColumns=@JoinColumn (name="weapons_id"),
            inverseJoinColumns=@JoinColumn(name="biomes_id")
    )
    private List<BiomesModel> Biomes;

    @OneToOne(optional = true, cascade = CascadeType.ALL)
    @JoinColumn(name="user_id")
    private UsersModel user;

    //Геттеры и сеттеры
    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getAttackSpeed() {
        return attackSpeed;
    }

    public void setAttackSpeed(double attackSpeed) {
        this.attackSpeed = attackSpeed;
    }

    public double getKnockback() {
        return knockback;
    }

    public void setKnockback(double knockback) {
        this.knockback = knockback;
    }

    public List<BiomesModel> getBiomes() {

        return Biomes;
    }

}
