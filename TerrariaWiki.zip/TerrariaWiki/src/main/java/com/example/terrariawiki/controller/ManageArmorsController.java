package com.example.terrariawiki.controller;

import com.example.terrariawiki.model.ArmorsModel;
import com.example.terrariawiki.repo.ArmorsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;

@Controller
@RequestMapping("/Armors")
public class ManageArmorsController {

    private final ArmorsRepo armorsRepo;

    @Autowired
    public ManageArmorsController(ArmorsRepo armorsRepo) {
        this.armorsRepo = armorsRepo;
    }

    @GetMapping("/MShowArmors")
    public String listArmors(Model model) {
        Iterable<ArmorsModel> armors = armorsRepo.findAll();
        model.addAttribute("armors", armors);
        return "Armors/MShowArmors";
    }

    @GetMapping("/MAddArmors")
    public String showAddArmorsForm(Model model) {
        ArmorsModel armor = new ArmorsModel();
        model.addAttribute("armor", armor);
        return "Armors/MAddArmors";
    }

    @PostMapping("/MAddArmors")
    public String addArmors(@Valid @ModelAttribute("armor") ArmorsModel armor, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "Armors/MAddArmors";
        }
        armorsRepo.save(armor);
        return "redirect:/Armors/MShowArmors";
    }

    @GetMapping("/MEditArmors/{id}")
    public String showEditArmorsForm(@PathVariable("id") Long id, Model model) {
        ArmorsModel armor = armorsRepo.findById(id).orElse(null);
        if (armor == null) {
            return "redirect:/Armors/MShowArmors";
        }
        model.addAttribute("armor", armor);
        return "Armors/MEditArmors";
    }

    @PostMapping("/MEditArmors/{id}")
    public String editArmors(@PathVariable("id") Long id, @Valid @ModelAttribute("armor") ArmorsModel armor, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "Armors/MEditArmors";
        }
        armor.setId(id);
        armorsRepo.save(armor);
        return "redirect:/Armors/MShowArmors";
    }

    @GetMapping("/delete/{id}")
    public String deleteArmors(@PathVariable("id") Long id) {
        armorsRepo.deleteById(id);
        return "redirect:/Armors/MShowArmors";
    }
}
