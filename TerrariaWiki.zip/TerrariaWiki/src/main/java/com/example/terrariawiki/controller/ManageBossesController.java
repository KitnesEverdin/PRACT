package com.example.terrariawiki.controller;

import com.example.terrariawiki.model.BossesModel;
import com.example.terrariawiki.repo.BossesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;

@Controller
@RequestMapping("/Bosses")
public class ManageBossesController {

    private final BossesRepo bossesRepo;

    @Autowired
    public ManageBossesController(BossesRepo bossesRepo) {
        this.bossesRepo = bossesRepo;
    }

    @GetMapping("/MShowBosses")
    public String listBosses(Model model) {
        Iterable<BossesModel> bosses = bossesRepo.findAll();
        model.addAttribute("bosses", bosses);
        return "Bosses/MShowBosses";
    }

    @GetMapping("/MAddBosses")
    public String showAddBossesForm(Model model) {
        BossesModel boss = new BossesModel();
        model.addAttribute("boss", boss);
        return "Bosses/MAddBosses";
    }

    @PostMapping("/MAddBosses")
    public String addBosses(@Valid @ModelAttribute("boss") BossesModel boss, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "Bosses/MAddBosses";
        }
        bossesRepo.save(boss);
        return "redirect:/Bosses/MShowBosses";
    }

    @GetMapping("/MEditBosses/{id}")
    public String showEditBossesForm(@PathVariable("id") Long id, Model model) {
        BossesModel boss = bossesRepo.findById(id).orElse(null);
        if (boss == null) {
            return "redirect:/Bosses/MShowBosses";
        }
        model.addAttribute("boss", boss);
        return "Bosses/MEditBosses";
    }

    @PostMapping("/MEditBosses/{id}")
    public String editBosses(@PathVariable("id") Long id, @Valid @ModelAttribute("boss") BossesModel boss, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "Bosses/MEditBosses";
        }
        boss.setId(id);
        bossesRepo.save(boss);
        return "redirect:/Bosses/MShowBosses";
    }

    @GetMapping("/delete/{id}")
    public String deleteBosses(@PathVariable("id") Long id) {
        bossesRepo.deleteById(id);
        return "redirect:/Bosses/MShowBosses";
    }
}
