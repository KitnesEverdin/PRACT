package com.example.terrariawiki.repo;

import com.example.terrariawiki.model.UsersModel;
import com.example.terrariawiki.model.roleEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;
@Repository
public interface UsersRepo extends JpaRepository<UsersModel, Long> {
    UsersModel findByUsername(String username);

    @Transactional
    @Modifying
    @Query("UPDATE UsersModel u SET u.roles = ?2 WHERE u.id = ?1")
    void updateUserRoleById(Long userId, String username, String password, Set<roleEnum> newRoles);
}
