package com.example.terrariawiki.controller;

import com.example.terrariawiki.model.AccessoriesModel;
import com.example.terrariawiki.repo.AccessoriesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;

@Controller
@RequestMapping("/Accessories")
public class ManageAccessoriesController {

    private final AccessoriesRepo accessoriesRepo;

    @Autowired
    public ManageAccessoriesController(AccessoriesRepo accessoriesRepo) {
        this.accessoriesRepo = accessoriesRepo;
    }

    @GetMapping("/MShowAccessories")
    public String listAccessories(Model model) {
        Iterable<AccessoriesModel> accessoriesList = accessoriesRepo.findAll();
        model.addAttribute("accessoriesList", accessoriesList);
        return "Accessories/MShowAccessories";
    }

    @GetMapping("/MAddAccessories")
    public String showAddAccessoriesForm(Model model) {
        AccessoriesModel accessory = new AccessoriesModel();
        model.addAttribute("accessory", accessory);
        return "Accessories/MAddAccessories";
    }

    @PostMapping("/MAddAccessories")
    public String addAccessories(@Valid @ModelAttribute("accessory") AccessoriesModel accessory, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "Accessories/MAddAccessories";
        }
        accessoriesRepo.save(accessory);
        return "redirect:/Accessories/MShowAccessories";
    }

    @GetMapping("/MEditAccessories/{id}")
    public String showEditAccessoriesForm(@PathVariable("id") Long id, Model model) {
        AccessoriesModel accessory = accessoriesRepo.findById(id).orElse(null);
        if (accessory == null) {
            return "redirect:/Accessories/MShowAccessories";
        }
        model.addAttribute("accessory", accessory);
        return "Accessories/MEditAccessories";
    }

    @PostMapping("/MEditAccessories/{id}")
    public String editAccessories(@PathVariable("id") Long id, @Valid @ModelAttribute("accessory") AccessoriesModel accessory, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "Accessories/MEditAccessories";
        }
        accessory.setId(id);
        accessoriesRepo.save(accessory);
        return "redirect:/Accessories/MShowAccessories";
    }

    @GetMapping("/delete/{id}")
    public String deleteAccessories(@PathVariable("id") Long id) {
        accessoriesRepo.deleteById(id);
        return "redirect:/Accessories/MShowAccessories";
    }
}
