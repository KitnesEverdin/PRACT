package com.example.terrariawiki.controller;


import com.example.terrariawiki.model.BiomesModel;
import com.example.terrariawiki.model.BossesModel;
import com.example.terrariawiki.model.NPCModel;
import com.example.terrariawiki.repo.BiomesRepo;
import com.example.terrariawiki.repo.BossesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/Bosses")
public class UserBossesController {

    private final BossesRepo _BossesRepo;

    @Autowired
    public UserBossesController(BossesRepo _BossesRepo) {
        this._BossesRepo = _BossesRepo;
    }

    @GetMapping("/ShowBosses")
    public String listBosses(Model model) {
        Iterable<BossesModel> bosses = _BossesRepo.findAll();
        model.addAttribute("boss", bosses);
        return "Bosses/ShowBosses";
    }
}