package com.example.terrariawiki.controller;

import com.example.terrariawiki.model.AccessoriesModel;
import com.example.terrariawiki.repo.AccessoriesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/Accessories")
public class UserAccessoriesController {

    private final AccessoriesRepo _AccessoriesRepo;

    @Autowired
    public UserAccessoriesController(AccessoriesRepo _AccessoriesRepo) {
        this._AccessoriesRepo = _AccessoriesRepo;
    }

    @GetMapping("/ShowAccessories")
    public String listAccessories(Model model) {
        Iterable<AccessoriesModel> accessories = _AccessoriesRepo.findAll();
        model.addAttribute("accessor", accessories);
        return "Accessories/ShowAccessories";
    }
}