package com.example.terrariawiki.model;

import javax.persistence.*;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.List;

@Entity
@Table(name="NPC")
public class NPCModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Имя не может быть пустым")
    @Size(max = 100, message = "Имя не может содержать более 100 символов")
    private String name;

    @NotBlank(message = "Поле Arrival не может быть пустым")
    @Size(max = 100, message = "Arrival не может содержать более 100 символов")
    private String arrival;

    @NotBlank(message = "Поле description не может быть пустым")
    @Size(max = 200, message = "Description не может содержать более 200 символов")
    private String description;

    @NotBlank(message = "Поле имени картинки не может быть пустым")
    private String imageName;

    //Связи
    @ManyToOne
    @JoinColumn(name = "biomes_id")
    private BiomesModel biome;


    //Геттеры и сеттеры
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getArrival() {
        return arrival;
    }

    public void setArrival(String arrival) {
        this.arrival = arrival;
    }

    public String getDescription() {
        return description;
    }

    public BiomesModel getBiome() {
        return biome;
    }

    public void setBiome(BiomesModel biome) {
        this.biome = biome;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }
}
