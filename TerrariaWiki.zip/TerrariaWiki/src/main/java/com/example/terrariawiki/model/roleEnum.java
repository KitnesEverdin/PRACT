package com.example.terrariawiki.model;

public enum roleEnum {
    USER,
    MANAGE,
    ADMIN
}
