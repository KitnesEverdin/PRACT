package com.example.terrariawiki.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    @GetMapping("/HomeUser")
    public String HomeUser(Model model) {
        return "HomeUser";
    }

    @GetMapping("/HomeManage")
    public String HomeManage(Model model) {
        return "manage/HomeManage";
    }

    @GetMapping("/HomeAdmin")
    public String HomeAdmin(Model model) {
        return "admin/HomeAdmin";
    }
}
