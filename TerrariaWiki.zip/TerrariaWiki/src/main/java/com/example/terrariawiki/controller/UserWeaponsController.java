package com.example.terrariawiki.controller;

import com.example.terrariawiki.model.WeaponsModel;
import com.example.terrariawiki.repo.WeaponsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/Weapons")
public class UserWeaponsController {
    private final WeaponsRepo _WeaponsRepo;

    @Autowired
    public UserWeaponsController(WeaponsRepo _WeaponsRepo) {
        this._WeaponsRepo = _WeaponsRepo;
    }

    @GetMapping("/ShowWeapons")
    public String listWeapons(Model model) {
        Iterable<WeaponsModel> weapons = _WeaponsRepo.findAll();
        model.addAttribute("weapon", weapons);
        return "Weapons/ShowWeapons";
    }

}
