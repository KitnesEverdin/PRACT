package com.example.terrariawiki.controller;

import com.example.terrariawiki.model.BiomesModel;
import com.example.terrariawiki.repo.BiomesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;

@Controller
@RequestMapping("/Biomes")
public class ManageBiomesController {

    private final BiomesRepo _biomesRepo;

    @Autowired
    public ManageBiomesController(BiomesRepo biomesRepo) {
        this._biomesRepo = biomesRepo;
    }

    @GetMapping("/MShowBiomes")
    public String listBiomes(Model model) {
        Iterable<BiomesModel> biomes = _biomesRepo.findAll();
        model.addAttribute("biomes", biomes);
        return "Biomes/MShowBiomes";
    }

    @GetMapping("/MAddBiomes")
    public String showAddBiomesForm(Model model) {
        BiomesModel biome = new BiomesModel();
        model.addAttribute("biome", biome);
        return "Biomes/MAddBiomes";
    }

    @PostMapping("/MAddBiomes")
    public String addBiome(@Valid @ModelAttribute("biome") BiomesModel biome, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "Biomes/MAddBiomes";
        }
        _biomesRepo.save(biome);
        return "redirect:/Biomes/MShowBiomes";
    }

    @GetMapping("/MEditBiomes/{id}")
    public String showEditBiomesForm(@PathVariable("id") long id, Model model) {
        BiomesModel biome = _biomesRepo.findById(id).orElse(null);
        if (biome == null) {
            return "redirect:/Biomes/MShowBiomes";
        }
        model.addAttribute("biome", biome);
        return "Biomes/MEditBiomes";
    }

    @PostMapping("/MEditBiomes/{id}")
    public String editBiome(@PathVariable("id") Long id, @Valid @ModelAttribute("biome") BiomesModel biome, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "Biomes/MEditBiomes";
        }
        biome.setId(id);
        _biomesRepo.save(biome);
        return "redirect:/Biomes/MShowBiomes";
    }

    @GetMapping("/delete/{id}")
    public String deleteBiome(@PathVariable("id") long id) {
        _biomesRepo.deleteById(id);
        return "redirect:/Biomes/MShowBiomes";
    }
}
