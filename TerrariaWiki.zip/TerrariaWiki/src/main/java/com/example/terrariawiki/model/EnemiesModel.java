package com.example.terrariawiki.model;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Set;

@Entity
@Table(name="Enemies")
public class EnemiesModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank(message = "Поле имени не может быть пустым")
    private String name;
    @NotNull(message = "Поле НР не может быть пустым")
    private int hp;
    @NotNull(message = "Поле защиты не может быть пустым")
    private int defense;
    @NotNull(message = "Поле атаки не может быть пустым")
    private int attack;
    @NotBlank(message = "Поле имени картинки не может быть пустым")
    private String imageName;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable (name="Biomes_Enemies",
            joinColumns=@JoinColumn (name="enemies_id"),
            inverseJoinColumns=@JoinColumn(name="biomes_id")
    )
    private List<BiomesModel> Biomes;

    public EnemiesModel() {}
    //Связи



    //Геттеры и сеттеры
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getDefense() {
        return defense;
    }

    public void setDefense(int defense) {
        this.defense = defense;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }


    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }



    public List<BiomesModel> getBiomes() {
        return Biomes;
    }
}

