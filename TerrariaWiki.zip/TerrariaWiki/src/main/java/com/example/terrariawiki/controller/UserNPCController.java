package com.example.terrariawiki.controller;

import com.example.terrariawiki.model.NPCModel;
import com.example.terrariawiki.repo.NPCRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/NPC")
public class UserNPCController {

    private final NPCRepo _NPCRepo;

    @Autowired
    public UserNPCController(NPCRepo _NPCRepo) {
        this._NPCRepo = _NPCRepo;
    }

    @GetMapping("/ShowNPC")
    public String listNPC(Model model) {
        Iterable<NPCModel> NPCs = _NPCRepo.findAll();
        model.addAttribute("NPC", NPCs);
        return "NPC/ShowNPC";
    }

}
