package com.example.terrariawiki.controller;

import com.example.terrariawiki.model.EnemiesModel;
import com.example.terrariawiki.repo.EnemiesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;

@Controller
@RequestMapping("/Enemies")
public class ManageEnemiesController {

    private final EnemiesRepo enemiesRepo;

    @Autowired
    public ManageEnemiesController(EnemiesRepo enemiesRepo) {
        this.enemiesRepo = enemiesRepo;
    }

    @GetMapping("/MShowEnemies")
    public String listEnemies(Model model) {
        Iterable<EnemiesModel> enemies = enemiesRepo.findAll();
        model.addAttribute("enemies", enemies);
        return "Enemies/MShowEnemies";
    }

    @GetMapping("/MAddEnemies")
    public String showAddEnemiesForm(Model model) {
        EnemiesModel enemy = new EnemiesModel();
        model.addAttribute("enemy", enemy);
        return "Enemies/MAddEnemies";
    }

    @PostMapping("/MAddEnemies")
    public String addEnemies(@Valid @ModelAttribute("enemy") EnemiesModel enemy, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "Enemies/MAddEnemies";
        }
        enemiesRepo.save(enemy);
        return "redirect:/Enemies/MShowEnemies";
    }

    @GetMapping("/MEditEnemies/{id}")
    public String showEditEnemiesForm(@PathVariable("id") Long id, Model model) {
        EnemiesModel enemy = enemiesRepo.findById(id).orElse(null);
        if (enemy == null) {
            return "redirect:/Enemies/MShowEnemies";
        }
        model.addAttribute("enemy", enemy);
        return "Enemies/MEditEnemies";
    }

    @PostMapping("/MEditEnemies/{id}")
    public String editEnemies(@PathVariable("id") Long id, @Valid @ModelAttribute("enemy") EnemiesModel enemy, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "Enemies/MEditEnemies";
        }
        enemy.setId(id);
        enemiesRepo.save(enemy);
        return "redirect:/Enemies/MShowEnemies";
    }

    @GetMapping("/delete/{id}")
    public String deleteEnemies(@PathVariable("id") Long id) {
        enemiesRepo.deleteById(id);
        return "redirect:/Enemies/MShowEnemies";
    }
}
