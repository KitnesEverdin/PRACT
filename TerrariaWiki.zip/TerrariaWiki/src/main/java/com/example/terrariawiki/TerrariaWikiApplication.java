package com.example.terrariawiki;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TerrariaWikiApplication {

    public static void main(String[] args) {
        SpringApplication.run(TerrariaWikiApplication.class, args);
    }

}
