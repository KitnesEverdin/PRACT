package com.example.terrariawiki.controller;

import com.example.terrariawiki.model.ArmorsModel;
import com.example.terrariawiki.repo.ArmorsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/Armors")
public class UserArmorsController {

    private final ArmorsRepo _ArmorsRepo;

    @Autowired
    public UserArmorsController(ArmorsRepo _ArmorsRepo) {
        this._ArmorsRepo = _ArmorsRepo;
    }

    @GetMapping("/ShowArmors")
    public String listArmors(Model model) {
        Iterable<ArmorsModel> armors = _ArmorsRepo.findAll();
        model.addAttribute("armor", armors);
        return "Armors/ShowArmors";
    }
}