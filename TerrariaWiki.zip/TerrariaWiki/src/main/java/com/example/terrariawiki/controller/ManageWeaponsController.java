package com.example.terrariawiki.controller;

import com.example.terrariawiki.model.WeaponsModel;
import com.example.terrariawiki.repo.WeaponsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;

@Controller
@RequestMapping("/Weapons")
public class ManageWeaponsController {

    private final WeaponsRepo weaponsRepo;

    @Autowired
    public ManageWeaponsController(WeaponsRepo weaponsRepo) {
        this.weaponsRepo = weaponsRepo;
    }

    @GetMapping("/MShowWeapons")
    public String listWeapons(Model model) {
        Iterable<WeaponsModel> weapons = weaponsRepo.findAll();
        model.addAttribute("weapons", weapons);
        return "Weapons/MShowWeapons";
    }

    @GetMapping("/MAddWeapons")
    public String showAddWeaponsForm(Model model) {
        WeaponsModel weapon = new WeaponsModel();
        model.addAttribute("weapon", weapon);
        return "Weapons/MAddWeapons";
    }

    @PostMapping("/MAddWeapons")
    public String addWeapons(@Valid @ModelAttribute("weapon") WeaponsModel weapon, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "Weapons/MAddWeapons";
        }
        weaponsRepo.save(weapon);
        return "redirect:/Weapons/MShowWeapons";
    }

    @GetMapping("/MEditWeapons/{id}")
    public String showEditWeaponsForm(@PathVariable("id") Long id, Model model) {
        WeaponsModel weapon = weaponsRepo.findById(id).orElse(null);
        if (weapon == null) {
            return "redirect:/Weapons/MShowWeapons";
        }
        model.addAttribute("weapon", weapon);
        return "Weapons/MEditWeapons";
    }

    @PostMapping("/MEditWeapons/{id}")
    public String editWeapons(@PathVariable("id") Long id, @Valid @ModelAttribute("weapon") WeaponsModel weapon, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "Weapons/MEditWeapons";
        }
        weapon.setId(id);
        weaponsRepo.save(weapon);
        return "redirect:/Weapons/MShowWeapons";
    }

    @GetMapping("/delete/{id}")
    public String deleteWeapons(@PathVariable("id") Long id) {
        weaponsRepo.deleteById(id);
        return "redirect:/Weapons/MShowWeapons";
    }
}
