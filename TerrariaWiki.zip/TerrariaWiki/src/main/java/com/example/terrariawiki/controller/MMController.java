package com.example.terrariawiki.controller;
import com.example.terrariawiki.model.BiomesModel;
import com.example.terrariawiki.model.BossesModel;
import com.example.terrariawiki.model.EnemiesModel;
import com.example.terrariawiki.model.WeaponsModel;
import com.example.terrariawiki.repo.BiomesRepo;
import com.example.terrariawiki.repo.BossesRepo;
import com.example.terrariawiki.repo.EnemiesRepo;
import com.example.terrariawiki.repo.WeaponsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/MM")
public class MMController {
    @Autowired
    private BiomesRepo _BiomesRepo;
    @Autowired
    private EnemiesRepo _EnemiesRepo;
    @Autowired
    private WeaponsRepo _WeaponsRepo;
    @Autowired
    private BossesRepo _BossesRepo;

    @GetMapping("/MShowEnemyBiome")
    public String listElementsAndCommands(Model model) {
        Iterable<EnemiesModel> enemies = _EnemiesRepo.findAll();
        Iterable<BiomesModel> biomes = _BiomesRepo.findAll();
        model.addAttribute("enemies", enemies);
        model.addAttribute("biomes", biomes);
        return "MM/MShowEnemyBiome";
    }

    @GetMapping("/MAddEnemyBiome")
    private String Main(Model model){
        Iterable<EnemiesModel> enemies = _EnemiesRepo.findAll();
        model.addAttribute("enemy", enemies);
        Iterable<BiomesModel> biomes = _BiomesRepo.findAll();
        model.addAttribute("biome", biomes);

        return "MM/MAddEnemyBiome";
    }

    @PostMapping("/MAddEnemyBiome")
    public String blogPostAdd(@RequestParam String enemy, @RequestParam String biome, RedirectAttributes redirectAttributes)
    {
        EnemiesModel enemies2 = _EnemiesRepo.findByName(enemy);
        BiomesModel biomes2 = _BiomesRepo.findByName(biome);

        if (!enemies2.getBiomes().contains(biomes2)) {
            enemies2.getBiomes().add(biomes2);
            biomes2.getEnemies().add(enemies2);
            _EnemiesRepo.save(enemies2);
        }
        redirectAttributes.addFlashAttribute("success", "Моб успешно добавлен в биом");
        return "redirect:/Enemies/MShowEnemies";
    }

    @GetMapping("/MShowBiomeWeapons")
    public String listBiomesAndWeapons(Model model) {
        Iterable<BiomesModel> biomes = _BiomesRepo.findAll();
        Iterable<WeaponsModel> weapons = _WeaponsRepo.findAll();
        model.addAttribute("biomes", biomes);
        model.addAttribute("weapons", weapons);
        return "MM/MShowBiomeWeapons";
    }

    @GetMapping("/MAddBiomeWeapons")
    public String MainBiomeWeapons(Model model){
        Iterable<BiomesModel> biomes = _BiomesRepo.findAll();
        model.addAttribute("biome", biomes);
        Iterable<WeaponsModel> weapons = _WeaponsRepo.findAll();
        model.addAttribute("weapon", weapons);
        return "MM/MAddBiomeWeapons";
    }

    @PostMapping("/MAddBiomeWeapons")
    public String blogPostAddBiomeWeapons(@RequestParam String weapon, @RequestParam String biome, RedirectAttributes redirectAttributes)
    {
        WeaponsModel weapon2 = _WeaponsRepo.findByName(weapon);
        BiomesModel biomes3 = _BiomesRepo.findByName(biome);

        if (!weapon2.getBiomes().contains(biomes3)) {
            weapon2.getBiomes().add(biomes3);
            biomes3.getWeapons().add(weapon2);
            _WeaponsRepo.save(weapon2);
        }
        redirectAttributes.addFlashAttribute("success", "Моб успешно добавлен в биом");
        return "redirect:/Weapons/MShowWeapons";
    }

    @GetMapping("/MAddBiomeBosses")
    public String MainBiomeBosses(Model model){
        Iterable<BiomesModel> biomes = _BiomesRepo.findAll();
        model.addAttribute("biome", biomes);
        Iterable<BossesModel> bosses = _BossesRepo.findAll();
        model.addAttribute("boss", bosses);
        return "MM/MAddBiomeBosses";
    }

    @PostMapping("/MAddBiomeBosses")
    public String blogPostAddBiomeBosses(@RequestParam String boss, @RequestParam String biome, RedirectAttributes redirectAttributes)
    {
        BossesModel bosses2 = _BossesRepo.findByName(boss);
        BiomesModel biomes4 = _BiomesRepo.findByName(biome);

        if (!bosses2.getBiomes().contains(biomes4)) {
            bosses2.getBiomes().add(biomes4);
            biomes4.getBosses().add(bosses2);
            _BossesRepo.save(bosses2);
        }
        redirectAttributes.addFlashAttribute("success", "Моб успешно добавлен в биом");
        return "redirect:/Bosses/MShowBosses";
    }
}
