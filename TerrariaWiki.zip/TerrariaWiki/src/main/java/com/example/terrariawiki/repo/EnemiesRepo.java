package com.example.terrariawiki.repo;

import com.example.terrariawiki.model.EnemiesModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EnemiesRepo extends CrudRepository<EnemiesModel, Long> {
    EnemiesModel findByName(String name);
}
