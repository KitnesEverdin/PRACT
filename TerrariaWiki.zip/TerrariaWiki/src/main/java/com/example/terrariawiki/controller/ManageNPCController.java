package com.example.terrariawiki.controller;

import com.example.terrariawiki.model.BiomesModel;
import com.example.terrariawiki.model.NPCModel;
import com.example.terrariawiki.repo.BiomesRepo;
import com.example.terrariawiki.repo.NPCRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;

@Controller
@RequestMapping("/NPC")
public class ManageNPCController {

    private final NPCRepo _NPCRepo;
    private final BiomesRepo _BiomesRepo;

    @Autowired
    public ManageNPCController(NPCRepo _NPCRepo, BiomesRepo _BiomesRepo) {

        this._NPCRepo = _NPCRepo;
        this._BiomesRepo = _BiomesRepo;
    }

    @GetMapping("/MShowNPC")
    public String listNPC(Model model) {
        Iterable<NPCModel> NPCs = _NPCRepo.findAll();
        model.addAttribute("NPCs", NPCs);
        return "NPC/MShowNPC";
    }

    @GetMapping("/MAddNPC")
    public String showAddNPCForm(Model model) {
        NPCModel npc = new NPCModel();
        model.addAttribute("npc", npc);
        Iterable<BiomesModel> biomes = _BiomesRepo.findAll();
        model.addAttribute("biomes", biomes);
        return "NPC/MAddNPC";
    }

    @PostMapping("/MAddNPC")
    public String addNPC(@Valid @ModelAttribute("npc") NPCModel npc, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "NPC/MAddNPC";
        }
        System.out.println("Name: " + npc.getName());
        _NPCRepo.save(npc);
        return "redirect:/NPC/MShowNPC";
    }

    @GetMapping("/MEditNPC/{id}")
    public String showEditNPCForm(@PathVariable("id") long id, Model model) {
        NPCModel npc = _NPCRepo.findById(id).orElse(null);
        if (npc == null) {
            return "redirect:/NPC/MShowNPC";
        }
        Iterable<BiomesModel> biomes = _BiomesRepo.findAll();
        model.addAttribute("biomes", biomes);
        model.addAttribute("npc", npc);
        return "NPC/MEditNPC";
    }

    @PostMapping("/MEditNPC/{id}")
    public String editNPC(@PathVariable("id") Long id, @Valid @ModelAttribute("npc") NPCModel npc, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "NPC/MEditNPC";
        }
        npc.setId(id);
        _NPCRepo.save(npc);
        return "redirect:/NPC/MShowNPC";
    }

    @GetMapping("/delete/{id}")
    public String deleteNPC(@PathVariable("id") long id) {
        _NPCRepo.deleteById(id);
        return "redirect:/NPC/MShowNPC";
    }
}
