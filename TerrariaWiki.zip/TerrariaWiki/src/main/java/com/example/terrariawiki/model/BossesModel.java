package com.example.terrariawiki.model;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

@Entity
@Table(name="Bosses")
public class BossesModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Поле названия не может быть пустым")
    private String name;

    @NotNull(message = "Поле атаки не может быть пустым")
    private int attack;

    @NotNull(message = "Поле защиты не может быть пустым")
    private int hp;
    @NotNull(message = "Поле защиты не может быть пустым")
    private int defense;
    @NotBlank(message = "Поле условия спавна не может быть пустым")
    private String spawnCondition;
    @NotBlank(message = "Поле имени картинки не может быть пустым")
    private String imageName;
    //Связи

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable (name="Biomes_Bosses",
            joinColumns=@JoinColumn (name="bosses_id"),
            inverseJoinColumns=@JoinColumn(name="biomes_id")
    )
    private List<BiomesModel> Biomes;


    //Геттеры и сеттеры
    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public int getDefense() {
        return defense;
    }

    public void setDefense(int defense) {
        this.defense = defense;
    }

    public String getSpawnCondition() {
        return spawnCondition;
    }


    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public void setSpawnCondition(String spawnCondition) {
        this.spawnCondition = spawnCondition;
    }

    public List<BiomesModel> getBiomes() {
        return Biomes;
    }

}
