package com.example.terrariawiki.repo;

import com.example.terrariawiki.model.ArmorsModel;
import org.springframework.data.repository.CrudRepository;

public interface ArmorsRepo extends CrudRepository<ArmorsModel, Long> {
    // Дополнительные методы, если необходимо
}
