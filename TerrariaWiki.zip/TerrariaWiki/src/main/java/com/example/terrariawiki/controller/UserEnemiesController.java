package com.example.terrariawiki.controller;

import com.example.terrariawiki.model.EnemiesModel;
import com.example.terrariawiki.repo.EnemiesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/Enemies")
public class UserEnemiesController {

    private final EnemiesRepo _EnemiesRepo;

    @Autowired
    public UserEnemiesController(EnemiesRepo _EnemiesRepo) {
        this._EnemiesRepo = _EnemiesRepo;
    }

    @GetMapping("/ShowEnemies")
    public String listEnemies(Model model) {
        Iterable<EnemiesModel> enemies = _EnemiesRepo.findAll();
        model.addAttribute("enemy", enemies);
        return "Enemies/ShowEnemies";
    }
}