package com.example.terrariawiki.controller;


import com.example.terrariawiki.model.BiomesModel;
import com.example.terrariawiki.repo.BiomesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/Biomes")
public class UserBiomesController {

    private final BiomesRepo _BiomesRepo;

    @Autowired
    public UserBiomesController(BiomesRepo _BiomesRepo) {
        this._BiomesRepo = _BiomesRepo;
    }

    @GetMapping("/ShowBiomes")
    public String listBiomes(Model model) {
        Iterable<BiomesModel> biomes = _BiomesRepo.findAll();
        model.addAttribute("biome", biomes);
        return "Biomes/ShowBiomes";
    }
}