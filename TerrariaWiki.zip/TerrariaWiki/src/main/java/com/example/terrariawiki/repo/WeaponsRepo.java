package com.example.terrariawiki.repo;

import com.example.terrariawiki.model.EnemiesModel;
import com.example.terrariawiki.model.WeaponsModel;
import org.springframework.data.repository.CrudRepository;

public interface WeaponsRepo extends CrudRepository<WeaponsModel, Long> {
    WeaponsModel findByName(String name);
}
