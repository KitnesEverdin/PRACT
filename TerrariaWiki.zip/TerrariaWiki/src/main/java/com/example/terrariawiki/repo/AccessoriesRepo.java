package com.example.terrariawiki.repo;

import com.example.terrariawiki.model.AccessoriesModel;
import org.springframework.data.repository.CrudRepository;

public interface AccessoriesRepo extends CrudRepository<AccessoriesModel, Long> {
    // Дополнительные методы, если необходимо
}
