package com.example.terrariawiki.repo;

import com.example.terrariawiki.model.BiomesModel;
import com.example.terrariawiki.model.EnemiesModel;
import org.springframework.data.repository.CrudRepository;

public interface BiomesRepo extends CrudRepository<BiomesModel, Long> {
    BiomesModel findByName(String name);
}
