package com.example.terrariawiki.repo;

import com.example.terrariawiki.model.BossesModel;
import com.example.terrariawiki.model.EnemiesModel;
import org.springframework.data.repository.CrudRepository;

public interface BossesRepo extends CrudRepository<BossesModel, Long> {
    BossesModel findByName(String name);
}
