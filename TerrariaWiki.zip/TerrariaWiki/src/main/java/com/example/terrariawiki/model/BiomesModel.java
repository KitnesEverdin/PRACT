package com.example.terrariawiki.model;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.util.Collection;
import java.util.List;
import java.util.Set;

@Entity
@Table(name="Biomes")
public class BiomesModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Поле названия не может быть пустым")
    private String name;

    @NotBlank(message = "Поле описания не может быть пустым")
    private String description;

    //Связи
    public BiomesModel() {}
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable (name="Biomes_Enemies",
            joinColumns=@JoinColumn (name="biomes_id"),
            inverseJoinColumns=@JoinColumn(name="enemies_id")
    )
    private List<EnemiesModel> Enemies;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable (name="Biomes_Bosses",
            joinColumns=@JoinColumn (name="biomes_id"),
            inverseJoinColumns=@JoinColumn(name="bosses_id")
    )
    private List<BossesModel> Bosses;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable (name="Biomes_Weapons",
            joinColumns=@JoinColumn (name="biomes_id"),
            inverseJoinColumns=@JoinColumn(name="weapons_id")
    )
    private List<WeaponsModel> Weapons;

    @OneToMany (mappedBy = "biome", fetch = FetchType.LAZY)
    private Collection<NPCModel> NPC;


    //Геттеры и сеттеры
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<EnemiesModel> getEnemies() {
        return Enemies;
    }
    public List<BossesModel> getBosses() {
        return Bosses;
    }
    public List<WeaponsModel> getWeapons() {
        return Weapons;
    }
}
