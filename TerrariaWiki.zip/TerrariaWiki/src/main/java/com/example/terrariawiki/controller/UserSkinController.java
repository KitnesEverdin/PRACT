package com.example.terrariawiki.controller;


import com.example.terrariawiki.model.*;
import com.example.terrariawiki.repo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Controller
@RequestMapping("/Bosses")
public class UserSkinController {

    private final UsersRepo _UsersRepo;
    private final WeaponsRepo _WeaponsRepo;
    private final ArmorsRepo _ArmorsRepo;
    private final AccessoriesRepo _AccessoriesRepo;

    @Autowired
    public UserSkinController(UsersRepo _UsersRepo, WeaponsRepo _WeaponsRepo, ArmorsRepo _ArmorsRepo, AccessoriesRepo _AccessoriesRepo) {
        this._UsersRepo = _UsersRepo;
        this._WeaponsRepo = _WeaponsRepo;
        this._ArmorsRepo = _ArmorsRepo;
        this._AccessoriesRepo = _AccessoriesRepo;
    }

    @GetMapping("/ShowSkin")
    public String listSkin(Model model) {
        Iterable<UsersModel> users = _UsersRepo.findAll();
        model.addAttribute("users", users);
        Iterable<WeaponsModel> weapons = _WeaponsRepo.findAll();
        model.addAttribute("weapons", weapons);
        Iterable<ArmorsModel> armors = _ArmorsRepo.findAll();
        model.addAttribute("armors", armors);
        Iterable<AccessoriesModel> accessories = _AccessoriesRepo.findAll();
        model.addAttribute("accessories", accessories);
        return "Skin/ShowSkin";
    }

    @GetMapping("/EditSkin/{id}")
    public String showEditSkinForm(@PathVariable("id") Long id, Model model) {
        UsersModel user = _UsersRepo.findById(id).orElse(null);
        if (user == null) {
            return "redirect:/Enemies/MShowEnemies";
        }
        model.addAttribute("skin", user);
        return "Skin/EditSkin";
    }

    @PostMapping("/EditSkin/{id}")
    public String editSkin(@PathVariable("id") Long id, @Valid @ModelAttribute("user") UsersModel user, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "Skin/EditSkin";
        }
        user.setId(id);
        _UsersRepo.save(user);
        return "redirect:/NPC/MShowNPC";
    }
}