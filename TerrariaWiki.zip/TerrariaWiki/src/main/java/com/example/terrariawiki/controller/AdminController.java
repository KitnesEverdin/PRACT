package com.example.terrariawiki.controller;

import com.example.terrariawiki.model.UsersModel;
import com.example.terrariawiki.model.roleEnum;
import com.example.terrariawiki.repo.UsersRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UsersRepo _UsersRepo;

    @GetMapping("/EditUsers")
    public String editAccess(Model model) {
        List<UsersModel> allUsers = (List<UsersModel>) _UsersRepo.findAll();
        model.addAttribute("users", allUsers);
        return "admin/EditUsers";
    }

    @PostMapping("/EditUsers/{userId}/edit")
    public String updateAccess(@PathVariable long userId, @RequestParam Set<roleEnum> roles) {
        // Получите пользователя по ID
        Optional<UsersModel> optionalUser = _UsersRepo.findById(userId);

        if (optionalUser.isPresent()) {
            UsersModel user = optionalUser.get();
            user.setRoles(roles);
            _UsersRepo.save(user);
        }

        return "redirect:/admin/EditUsers";
    }

}
