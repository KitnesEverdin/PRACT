package com.example.terrariawiki.controller;

import com.example.terrariawiki.model.UsersModel;
import com.example.terrariawiki.model.roleEnum;
import com.example.terrariawiki.repo.UsersRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Collections;

@Controller
public class AllUsersController {
    @Autowired
    private UsersRepo _usersRepo;

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/reg")
    public String registration() {
        return "reg";
    }
    @PostMapping("/reg")
    public String addUser(UsersModel user, Model model) {
        UsersModel userFromDb = _usersRepo.findByUsername(user.getUsername());

        if (userFromDb != null) {
            model.addAttribute("message", "Пользователь уже зарегистрирован");
            return "reg";
        }

        user.setActive(true);
        user.setRoles(Collections.singleton(roleEnum.USER));
        user.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));
        _usersRepo.save(user);

        return "redirect:login";
    }

}
