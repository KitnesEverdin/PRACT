package com.example.terrariawiki.model;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="Armor")
public class ArmorsModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Поле названия не может быть пустым")
    private String name;

    @NotBlank(message = "Поле класса не может быть пустым")
    private String armorClass;

    @NotBlank(message = "Поле сет-бонуса не может быть пустым")
    private String setBonus;

    @NotNull(message = "Поле общей защиты не может быть пустым")
    private int totalDefense;
    @NotBlank(message = "Поле имени картинки не может быть пустым")
    private String imageName;
    //Связи

    @OneToOne(optional = true, cascade = CascadeType.ALL)
    @JoinColumn(name="user_id")
    private UsersModel user;

    //Геттеры и сеттеры
    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getArmorClass() {
        return armorClass;
    }

    public void setArmorClass(String armorClass) {
        this.armorClass = armorClass;
    }

    public String getSetBonus() {
        return setBonus;
    }

    public void setSetBonus(String setBonus) {
        this.setBonus = setBonus;
    }

    public int getTotalDefense() {
        return totalDefense;
    }

    public void setTotalDefense(int totalDefense) {
        this.totalDefense = totalDefense;
    }
}
